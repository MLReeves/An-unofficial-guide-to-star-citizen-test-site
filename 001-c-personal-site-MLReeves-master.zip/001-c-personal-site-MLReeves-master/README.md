# 001-c-personal-site-MLReeves
001-c-personal-site-MLReeves created by GitHub Classroom

What have you learned about html that helped you build this site?
the img tag was helpful for providing sense to the site.

What do you wish to change about your site when we style it?
make it look smoother, add some blues and grays. I also want to add buttons.
